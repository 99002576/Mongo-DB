package com.ltts.milecalculator;

import java.util.List;

public interface MileCalculator {
	void showMileage();

}
