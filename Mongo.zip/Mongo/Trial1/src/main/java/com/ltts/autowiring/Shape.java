package com.ltts.autowiring;

public interface Shape {

	void calculateArea(int x,int y);
}
